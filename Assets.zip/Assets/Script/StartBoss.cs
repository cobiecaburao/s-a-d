using UnityEngine;
using UnityEngine.UI;

public class StartBoss : MonoBehaviour
{
    [SerializeField] Image _healthBar;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            _healthBar.enabled = true;
        }
    }
}
