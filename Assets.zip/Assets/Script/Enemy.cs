using System.Collections;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public SpriteRenderer _spriteRenderer;
    [SerializeField] private Animator _animator;
    [SerializeField] BoxCollider2D _trigger;

    [SerializeField] private float _attackTime = 0.2f;
    [SerializeField] Color _custom;
    public int damage;
    public float _maxHealth;
    public float _health;

    public Transform playerTransform;
    public Rigidbody2D rb;
    private float moveSpeed = 0;
    public float setMoveSpeed;
    Vector2 moveDir;


    private void Start()
    {
        playerTransform = GameObject.Find("Player").transform;
        
        _health = _maxHealth;
    }
    private void Update()
    {
        if (_trigger.enabled == true)
        {
            moveSpeed = setMoveSpeed;
        }
        if (playerTransform)
        {
            Vector2 direction = (playerTransform.position - transform.position).normalized;
            moveDir = direction;
            rb.linearVelocity = new Vector2(moveDir.x, moveDir.y) * moveSpeed;
        }
    }

    public void TakeDamage(int damage)
    {
        _health -= damage;
        StartCoroutine(DamageFrame());

        if (_health <= 0)
        {
            Destroy(gameObject);
        }
    }

    private IEnumerator DamageFrame()
    {
        _spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(_attackTime);
        _spriteRenderer.color = _custom;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            PlayerHealth player = other.GetComponent<PlayerHealth>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
    }


}
