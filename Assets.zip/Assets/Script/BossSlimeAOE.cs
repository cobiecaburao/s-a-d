using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class BossSlimeAOE : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    
    [SerializeField] GameObject _aOE;
    [SerializeField] GameObject _slime1;
    [SerializeField] GameObject _slime2;
    [SerializeField] GameObject _roomAttack;
    [SerializeField] GameObject _lazerAttack;

    [SerializeField] float _attackInterval = 0.3f;
    [SerializeField] float _attackCooldown = 3f;
    [SerializeField] float _attackCooldown1 = 7f;
    [SerializeField] float _attackCooldown2 = 7.5f;
    [SerializeField] float _spawnCooldown = 10f;

    private bool _hasAttacked1 = false;
    private bool _hasAttacked2 = false;

    public float radius = 8f;
    public Transform playerTransform;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerTransform = GameObject.Find("Player").transform;
        float distance = Vector2.Distance(transform.position, playerTransform.position);

        if (playerTransform != null)
        {
            if (distance <= radius)
            {
                StartCoroutine(Shoot());
                StartCoroutine(Spawn());
                StartCoroutine(Attack1());
                StartCoroutine(Attack2());
            }
        }
    }
    private IEnumerator Shoot()
    {
        _animator.SetBool("IsShooting", false);
        yield return new WaitForSeconds(_attackCooldown);
        
        _animator.SetBool("IsShooting", true);
        GameObject newAOE1 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        yield return new WaitForSeconds(_attackInterval);
        GameObject newAOE2 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        yield return new WaitForSeconds(_attackInterval);
        GameObject newAOE3 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        yield return new WaitForSeconds(_attackInterval);
        GameObject newAOE4 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        yield return new WaitForSeconds(_attackInterval);
        GameObject newAOE5 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        yield return new WaitForSeconds(_attackInterval);
        GameObject newAOE6 = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
            
        StartCoroutine(Shoot());

    }

    private IEnumerator Spawn()
    {

        yield return new WaitForSeconds(_spawnCooldown);
        _animator.SetBool("IsShooting", true);
        GameObject newAOE1 = Instantiate(_aOE, new Vector2(-5, 17), transform.rotation);
        GameObject newAOE2 = Instantiate(_aOE, new Vector2(6, 9), transform.rotation);
        GameObject newAOE3 = Instantiate(_aOE, new Vector2(-6, 10), transform.rotation);
        GameObject newAOE4 = Instantiate(_aOE, new Vector2(-4, 8), transform.rotation);
        GameObject newAOE5 = Instantiate(_aOE, new Vector2(5, 18), transform.rotation);
        GameObject newAOE6 = Instantiate(_aOE, new Vector2(7, 16), transform.rotation);
        yield return new WaitForSeconds(2.5f);
        GameObject newSlime1 = Instantiate(_slime1, new Vector2(-5, 17), transform.rotation);
        GameObject newSlime2 = Instantiate(_slime1, new Vector2(6, 9), transform.rotation);
        GameObject newSlime3 = Instantiate(_slime2, new Vector2(-6, 10), transform.rotation);
        GameObject newSlime4 = Instantiate(_slime2, new Vector2(-4, 8), transform.rotation);
        GameObject newSlime5 = Instantiate(_slime2, new Vector2(5, 18), transform.rotation);
        GameObject newSlime6 = Instantiate(_slime2, new Vector2(7, 16), transform.rotation);
        yield return new WaitForSeconds(1.5f);
        _animator.SetBool("IsShooting", false);
        StartCoroutine(Spawn());
    }

    private IEnumerator Attack1()
    {
        if (_hasAttacked1 == false)
        {
            yield return new WaitForSeconds(15);
        }

        GameObject newAttack1 = Instantiate(_lazerAttack, transform.position, transform.rotation);
        _hasAttacked1 = true;
        yield return new WaitForSeconds(_attackCooldown1);
        StartCoroutine(Attack1());
        

    }

    private IEnumerator Attack2()
    {
        if (_hasAttacked2 == false)
        {
            yield return new WaitForSeconds(18);
        }

        _animator.SetBool("IsShooting", true);
        GameObject newAttack1 = Instantiate(_roomAttack, transform.position, transform.rotation);
        yield return new WaitForSeconds(1.5f);
        _animator.SetBool("IsShooting", false);
        GetComponent<Boss>()._phase3 = false;
        _hasAttacked2 = true;
        yield return new WaitForSeconds(_attackCooldown2);
        StartCoroutine(Attack2());
    }
}
