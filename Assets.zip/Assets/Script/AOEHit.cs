using System.Collections;
using System.Data;
using UnityEngine;

public class AOEHit : MonoBehaviour
{
    [SerializeField] private float _attackTime = 0.2f;
    public int damage = 1;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    
    private IEnumerator OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            PlayerHealth player = other.GetComponent<PlayerHealth>();
            if (player != null)
            {
                player.TakeDamage(damage);
                player._spriteRenderer.color = Color.red;
                yield return new WaitForSeconds(_attackTime);
                player._spriteRenderer.color = Color.white;
            }


        }
    }
}
