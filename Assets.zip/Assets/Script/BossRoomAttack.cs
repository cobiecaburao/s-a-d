using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BossRoomAttack : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] GameObject _roomAttack;
    [SerializeField] GameObject _lazerAttack;
    public float _attackCooldown1 = 7f;
    public float _attackCooldown2 = 7.5f;

    private IEnumerator Attack1()
    {
        GetComponent<Boss>()._phase2 = true;
        if (GetComponent<Boss>()._phase2 == true)
        {
            GameObject newAttack1 = Instantiate(_lazerAttack, transform.position, transform.rotation);
            GetComponent<Boss>()._phase2 = false;
            yield return new WaitForSeconds(_attackCooldown1);
            StartCoroutine(Attack1());
        }

    }

    private IEnumerator Attack2()
    {
        GetComponent<Boss>()._phase3 = true;
        if (GetComponent<Boss>()._phase3 == true)
        {
            _animator.SetBool("IsShooting", true);
            GameObject newAttack1 = Instantiate(_roomAttack, transform.position, transform.rotation);
            yield return new WaitForSeconds(1.5f);
            _animator.SetBool("IsShooting", false);
            GetComponent<Boss>()._phase3 = false;
            yield return new WaitForSeconds(_attackCooldown2);
            StartCoroutine(Attack2());
        }

    }
}
