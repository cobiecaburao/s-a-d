using UnityEngine;

public class TriggerRoom : MonoBehaviour
{
    [SerializeField] BoxCollider2D _trigger;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            _trigger.enabled = true;
        }
    }
}
