using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] GameObject _slime1;
    [SerializeField] GameObject _slime2;
    
    private void Update()
    {
        if (GetComponent<Boss>()._phase2 == true)
        {
            Spawn();
        }
        if (GetComponent<Boss>()._phase3 == true)
        {
            Spawn();
        }
    }
    private void Spawn()
    {

        _animator.SetBool("IsShooting", true);
        GameObject newSlime1 = Instantiate(_slime1, new Vector2(-5, 17), transform.rotation);
        GameObject newSlime2 = Instantiate(_slime1, new Vector2(6, 9), transform.rotation);
        GameObject newSlime3 = Instantiate(_slime2, new Vector2(-6, 10), transform.rotation);
        GameObject newSlime4 = Instantiate(_slime2, new Vector2(-4, 8), transform.rotation);
        GameObject newSlime5 = Instantiate(_slime2, new Vector2(5, 18), transform.rotation);
        GameObject newSlime6 = Instantiate(_slime2, new Vector2(7, 16), transform.rotation);
        StartCoroutine(Pause());

    }

    private IEnumerator Pause()
    {
        yield return new WaitForSeconds(1.5f);
        _animator.SetBool("IsShooting", false);
        yield return new WaitForSeconds(100f);
    }
}
