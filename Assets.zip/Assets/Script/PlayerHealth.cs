using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem.Processors;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] public SpriteRenderer _spriteRenderer;
    public int _maxHealth = 6;
    public int _health;

    public Image heart1;
    public Image heart2;
    public Image heart3;
    public Image heart4;
    public Image heart5;

    [SerializeField] private float _attackTime = 0.2f;
    public float _iFrameTime = 1.5f;
    private bool _isInvincible = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _health = _maxHealth;
    }

    private void Update()
    {
        HealthBar();
    }

    private void HealthBar()
    {
        if (_health == 10)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 1;
            heart4.fillAmount = 1;
            heart5.fillAmount = 1;
        }
        else if (_health == 9)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 1;
            heart4.fillAmount = 1;
            heart5.fillAmount = 0.5f;
        }
        else if (_health == 8)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 1;
            heart4.fillAmount = 1;
            heart5.fillAmount = 0;
        }
        else if (_health == 7)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 1;
            heart4.fillAmount = 0.5f;
            heart5.fillAmount = 0;
        }
        else if (_health == 6)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 1;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 5)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 0.5f;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 4)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 1;
            heart3.fillAmount = 0;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 3)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 0.5f;
            heart3.fillAmount = 0;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 2)
        {
            heart1.fillAmount = 1;
            heart2.fillAmount = 0;
            heart3.fillAmount = 0;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 1)
        {
            heart1.fillAmount = 0.5f;
            heart2.fillAmount = 0;
            heart3.fillAmount = 0;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
        else if (_health == 0)
        {
            heart1.fillAmount = 0;
            heart2.fillAmount = 0;
            heart3.fillAmount = 0;
            heart4.fillAmount = 0;
            heart5.fillAmount = 0;
        }
    }
    public void TakeDamage(int damage)
    {
        if (!_isInvincible)
        {
            _health -= damage;
            StartCoroutine(BecomeInvincible());
            _spriteRenderer.color = Color.red;
            StartCoroutine(DamageFrame());
            _spriteRenderer.color = Color.white;
        }
        
        if (_health <= 0)
        {
            _animator.SetBool("IsDead", true);
            GetComponent<PlayerMovement>().rb.linearVelocity = new Vector2(0, 0);
            GetComponent<PlayerMovement>().enabled = false;
        }
    }

    private IEnumerator DamageFrame()
    {
        yield return new WaitForSeconds(_attackTime);
    }

    private IEnumerator BecomeInvincible()
    {
        _isInvincible = true;
        yield return new WaitForSeconds(_iFrameTime);
        _isInvincible = false;
    }
}
