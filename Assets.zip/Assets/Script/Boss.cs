using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Boss : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    public SpriteRenderer _spriteRenderer;
    public float _maxHealth = 120f;
    public float _health;
    [SerializeField] Color _custom;
    public Image healthBar;

    public bool _phase2 = false;
    public bool _phase3 = false;

    [SerializeField] private float _attackTime = 0.2f;
    public int damage;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _health = _maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        healthBar.fillAmount = Mathf.Clamp(_health / _maxHealth, 0, 1);
        if (healthBar.fillAmount == 0.75)
        {
            _phase2 = true;
        }

        if (healthBar.fillAmount == 0.5)
        {
            _phase3 = true;
        }
    }

    public void TakeDamage(int damage)
    {
        _health -= damage;
        StartCoroutine(DamageFrame());

        if (_health <= 0)
        {
            Destroy(gameObject);
        }
    }

    private IEnumerator DamageFrame()
    {
        _spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(_attackTime);
        _spriteRenderer.color = _custom;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            PlayerHealth player = other.GetComponent<PlayerHealth>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
    }
}
