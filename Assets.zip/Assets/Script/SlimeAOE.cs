using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class SlimeAOE : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] GameObject _aOE;
    [SerializeField] float _attackInterval;
    public float radius = 5f;
    public Transform playerTransform;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerTransform = GameObject.Find("Player").transform;
        if (playerTransform != null)
        {
            StartCoroutine(Shoot());
            //GameObject newAOE = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
        }
    }
    private IEnumerator Shoot()
    {
        yield return new WaitForSeconds(1.5f);
        _animator.SetBool("IsShooting", false);
        _attackInterval = Random.Range(0f, 1f);
        yield return new WaitForSeconds(_attackInterval);
        float distance = Vector2.Distance(transform.position, playerTransform.position);
        if (distance <= radius)
        {
            GameObject newAOE = Instantiate(_aOE, playerTransform.position, playerTransform.rotation);
            _animator.SetBool("IsShooting", true);
        }
        StartCoroutine(Shoot());

    }
}
